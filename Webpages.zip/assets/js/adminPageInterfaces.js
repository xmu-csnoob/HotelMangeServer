insertBook=function (){
    const userName = document.getElementById("sideBarUserName").innerText;
    window.location.href="../../../pages/Admin/data/insertBook.html?value=" + userName;
}
insertUser=function (){
    const userName = document.getElementById("sideBarUserName").innerText;
    window.location.href="../../../pages/Admin/data/insertUser.html?value=" + userName;
}
alterBook=function (){
    const userName = document.getElementById("sideBarUserName").innerText;
    window.location.href="../../../pages/Admin/data/alterBook.html?value=" + userName;
}
alterUser=function (){
    const userName = document.getElementById("sideBarUserName").innerText;
    window.location.href="../../../pages/Admin/data/alterUser.html?value=" + userName;
}
adminAlterEmail=function (){
    const userName = document.getElementById("sideBarUserName").innerText;
    window.location.href="../../../pages/Admin/account/adminAlterEmail.html?value=" + userName;
}
adminSearchBooks=function (){
    const userName = document.getElementById("sideBarUserName").innerText;
    window.location.href="../../../pages/Admin/data/searchBook.html?value=" + userName;
}
adminAlterPassword=function (){
    const userName = document.getElementById("sideBarUserName").innerText;
    window.location.href="../../../pages/Admin/account/adminAlterPassword.html?value=" + userName;
}
returnHome=function (){
    const userName = document.getElementById("sideBarUserName").innerText;
    window.location.href="../../../pages/Admin/home/adminHome.html?value=" + userName;
}
allUsersClicked=function(){
    console.log("here");
    const userName = document.getElementById("sideBarUserName").innerText;
    window.location.href="../../../pages/Admin/data/allUser.html?value=" + userName;
}
allBooksClicked=function(){
    console.log("here");
    const userName = document.getElementById("sideBarUserName").innerText;
    window.location.href="../../../pages/Admin/data/allBook.html?value=" + userName;
}
allRentalsClicked=function(){
    console.log("here");
    const userName = document.getElementById("sideBarUserName").innerText;
    window.location.href="../../../pages/Admin/data/allRental.html?value=" + userName;
}
allBreachClicked=function (){
    console.log("here");
    const userName = document.getElementById("sideBarUserName").innerText;
    window.location.href="../../../pages/Admin/data/allBreach.html?value=" + userName
}
searchPayment=function(){
    const userName = document.getElementById("sideBarUserName").innerText;
    window.location.href="../../../pages/Admin/data/searchPayment.html?value=" + userName;
}
adminAlterTel=function(){
    console.log("here");
    const userName = document.getElementById("sideBarUserName").innerText;
    window.location.href="../../../pages/Admin/account/adminAlterTel.html?value=" + userName;
}
gotoUserLogin=function (){
    window.location.href="pages/User/home/userLogin.html";
}
gotoUserRegister=function (){
    window.location.href="pages/User/home/userRegister.html";
}
gotoAdminLogin=function (){
    window.location.href="pages/Admin/home/adminLogin.html";
}
GetRequest=function () {
    const url = location.search;
    const theRequest = {};
    let strs;
    if (url.indexOf("?") !== -1) {
        const str = url.substr(1);
        strs = str.split("&");
        for (let i = 0; i < strs.length; i++) {
            theRequest[strs[i].split("=")[0]] = decodeURIComponent(strs[i].split("=")[1]);
        }
    }
    return theRequest;
}