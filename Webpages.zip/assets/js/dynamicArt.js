blingbling=function(obj){
    obj.style="width:250px;background-image: -webkit-linear-gradient(120deg,#6559ae,#ff7159,#6559ae);-webkit-animation: hue 6s infinite linear;transform-origin: bottom right";
}