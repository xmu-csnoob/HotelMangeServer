function fillFooterDOM() {
    var footer = document.getElementById("footer");
    //console.log("fillFooterDOM");
    var content = "<aside class=\"main-sidebar\">\n" +
        "\t\t\t<div class=\"user-panel\">\n" +
        "\t\t\t\t<div class=\"image pull-left\">\n" +
        "\t\t\t\t\t<img src=\"../../../assets/avatars/avatars.png\" alt=\"\">\n" +
        "\t\t\t\t</div>\n" +
        "\t\t\t\t<div class=\"info pull-right\">\n" +
        "\t\t\t\t\t<p id=\"sideBarUserName\" class=\"title\">Alpha</p>\n" +
        "\t\t\t\t\t<strong>管理员</strong>\n" +
        "\t\t\t\t</div>\n" +
        "\t\t\t</div>\n" +
        "\t\t\t<section class=\"sidebar\">\n" +
        "\t\t\t\t<ul class=\"sidebar-menu\" data-widget=\"tree\">\n" +
        "\t\t\t\t\t<li class=\"active\">\n" +
        "\t\t\t\t\t\t<a href=\"javascript:returnHome()\" title=\"我的主页\">\n" +
        "\t\t\t\t\t\t\t<i class=\"iconfont icon-dashborad\"></i>\n" +
        "\t\t\t\t\t\t\t<small>我的主页</small>\n" +
        "\t\t\t\t\t\t</a>\n" +
        "\t\t\t\t\t</li>\n" +
        "\t\t\t\t\t<li class=\"treeview\">\n" +
        "\t\t\t\t\t\t<a href=\"#\" title=\"图书管理\">\n" +
        "\t\t\t\t\t\t\t<i class=\"iconfont icon-form\"></i>\n" +
        "\t\t\t\t\t\t\t<small>图书管理</small>\n" +
        "\t\t\t\t\t\t\t<span class=\" pull-right\">\n" +
        "\t\t\t\t\t\t\t\t<i class=\"iconfont icon-menu-left-small\"></i>\n" +
        "\t\t\t\t\t\t\t</span>\n" +
        "\t\t\t\t\t\t</a>\n" +
        "\t\t\t\t\t\t<ul class=\"treeview-menu\">\n" +
        "\t\t\t\t\t\t\t<li>\n" +
        "\t\t\t\t\t\t\t\t<a href=\"javascript:allBooksClicked()\">\n" +
        "\t\t\t\t\t\t\t\t\t<i class=\"iconfont icon-circle-hollow\"></i>\n" +
        "\t\t\t\t\t\t\t\t\t<small>所有图书</small>\n" +
        "\t\t\t\t\t\t\t\t</a>\n" +
        "\t\t\t\t\t\t\t</li>\n" +
        "\t\t\t\t\t\t\t<li>\n" +
        "\t\t\t\t\t\t\t\t<a href=\"javascript:alterBook()\">\n" +
        "\t\t\t\t\t\t\t\t\t<i class=\"iconfont icon-circle-hollow\"></i>\n" +
        "\t\t\t\t\t\t\t\t\t<small>修改图书</small>\n" +
        "\t\t\t\t\t\t\t\t</a>\n" +
        "\t\t\t\t\t\t\t</li>\n" +
        "\t\t\t\t\t\t\t<li>\n" +
        "\t\t\t\t\t\t\t\t<a href=\"javascript:insertBook()\">\n" +
        "\t\t\t\t\t\t\t\t\t<i class=\"iconfont icon-circle-hollow\"></i>\n" +
        "\t\t\t\t\t\t\t\t\t<small>增删图书</small>\n" +
        "\t\t\t\t\t\t\t\t</a>\n" +
        "\t\t\t\t\t\t\t</li>\n" +
        "\t\t\t\t\t\t\t<li>\n" +
        "\t\t\t\t\t\t\t\t<a href=\"javascript:adminSearchBooks()\">\n" +
        "\t\t\t\t\t\t\t\t\t<i class=\"iconfont icon-circle-hollow\"></i>\n" +
        "\t\t\t\t\t\t\t\t\t<small>查找图书</small>\n" +
        "\t\t\t\t\t\t\t\t</a>\n" +
        "\t\t\t\t\t\t\t</li>\n" +
        "\t\t\t\t\t\t</ul>\n" +
        "\t\t\t\t\t</li>\n" +
        "\t\t\t\t\t<li class=\"treeview\">\n" +
        "\t\t\t\t\t\t<a href=\"#\" title=\"UI元素\">\n" +
        "\t\t\t\t\t\t\t<i class=\"iconfont icon-components\"></i>\n" +
        "\t\t\t\t\t\t\t<small>用户管理</small>\n" +
        "\t\t\t\t\t\t\t<span class=\" pull-right\">\n" +
        "\t\t\t\t\t\t\t\t<i class=\"iconfont icon-menu-left-small\"></i>\n" +
        "\t\t\t\t\t\t\t</span>\n" +
        "\t\t\t\t\t\t</a>\n" +
        "\t\t\t\t\t\t<ul class=\"treeview-menu\">\n" +
        "\t\t\t\t\t\t\t<li>\n" +
        "\t\t\t\t\t\t\t\t<a href=\"javascript:allUsersClicked()\">\n" +
        "\t\t\t\t\t\t\t\t\t<i class=\"iconfont icon-circle-hollow\"></i>\n" +
        "\t\t\t\t\t\t\t\t\t<small>所有用户</small>\n" +
        "\t\t\t\t\t\t\t\t</a>\n" +
        "\t\t\t\t\t\t\t</li>\n" +
        "\t\t\t\t\t\t\t<li>\n" +
        "\t\t\t\t\t\t\t\t<a href=\"javascript:alterUser()\">\n" +
        "\t\t\t\t\t\t\t\t\t<i class=\"iconfont icon-circle-hollow\"></i>\n" +
        "\t\t\t\t\t\t\t\t\t<small>修改用户</small>\n" +
        "\t\t\t\t\t\t\t\t</a>\n" +
        "\t\t\t\t\t\t\t</li>\n" +
        "\t\t\t\t\t\t\t<li>\n" +
        "\t\t\t\t\t\t\t\t<a href=\"javascript:insertUser()\">\n" +
        "\t\t\t\t\t\t\t\t\t<i class=\"iconfont icon-circle-hollow\"></i>\n" +
        "\t\t\t\t\t\t\t\t\t<small>增删用户</small>\n" +
        "\t\t\t\t\t\t\t\t</a>\n" +
        "\t\t\t\t\t\t\t</li>\n" +
        "\t\t\t\t\t\t</ul>\n" +
        "\t\t\t\t\t</li>\n" +
        "\t\t\t\t\t<li class=\"treeview\">\n" +
        "\t\t\t\t\t\t<a href=\"#\" title=\"借阅管理\">\n" +
        "\t\t\t\t\t\t\t<i class=\"iconfont icon-form\"></i>\n" +
        "\t\t\t\t\t\t\t<small>借阅管理</small>\n" +
        "\t\t\t\t\t\t\t<span class=\" pull-right\">\n" +
        "\t\t\t\t\t\t\t\t<i class=\"iconfont icon-menu-left-small\"></i>\n" +
        "\t\t\t\t\t\t\t</span>\n" +
        "\t\t\t\t\t\t</a>\n" +
        "\t\t\t\t\t\t<ul class=\"treeview-menu\">\n" +
        "\t\t\t\t\t\t\t<li>\n" +
        "\t\t\t\t\t\t\t\t<a href=\"javascript:allRentalsClicked()\">\n" +
        "\t\t\t\t\t\t\t\t\t<i class=\"iconfont icon-circle-hollow\"></i>\n" +
        "\t\t\t\t\t\t\t\t\t<small>所有借阅情况</small>\n" +
        "\t\t\t\t\t\t\t\t</a>\n" +
        "\t\t\t\t\t\t\t</li>\n" +
        "\t\t\t\t\t\t\t<li>\n" +
        "\t\t\t\t\t\t\t\t<a href=\"javascript:allBreachClicked()\">\n" +
        "\t\t\t\t\t\t\t\t\t<i class=\"iconfont icon-circle-hollow\"></i>\n" +
        "\t\t\t\t\t\t\t\t\t<small>所有违约情况</small>\n" +
        "\t\t\t\t\t\t\t\t</a>\n" +
        "\t\t\t\t\t\t\t</li>\n" +
        "\t\t\t\t\t\t\t<li>\n" +
        "\t\t\t\t\t\t\t\t<a href=\"javascript:searchPayment()\">\n" +
        "\t\t\t\t\t\t\t\t\t<i class=\"iconfont icon-circle-hollow\"></i>\n" +
        "\t\t\t\t\t\t\t\t\t<small>查询缴款记录</small>\n" +
        "\t\t\t\t\t\t\t\t</a>\n" +
        "\t\t\t\t\t\t\t</li>\n" +
        "\t\t\t\t\t\t</ul>\n" +
        "\t\t\t\t\t</li>\n" +
        "\t\t\t\t\t<li class=\"treeview\">\n" +
        "\t\t\t\t\t\t<a href=\"#\">\n" +
        "\t\t\t\t\t\t\t<i class=\"iconfont icon-folder\"></i>\n" +
        "\t\t\t\t\t\t\t<small>账号管理</small>\n" +
        "\t\t\t\t\t\t\t<span class=\" pull-right\">\n" +
        "\t\t\t\t\t\t\t\t<i class=\"iconfont icon-menu-left-small\"></i>\n" +
        "\t\t\t\t\t\t\t</span>\n" +
        "\t\t\t\t\t\t</a>\n" +
        "\t\t\t\t\t\t<ul class=\"treeview-menu\">\n" +
        "\t\t\t\t\t\t\t<li>\n" +
        "\t\t\t\t\t\t\t\t<a href=\"javascript:adminAlterPassword()\">\n" +
        "\t\t\t\t\t\t\t\t\t<i class=\"iconfont icon-circle-hollow\"></i>\n" +
        "\t\t\t\t\t\t\t\t\t<small>修改密码</small>\n" +
        "\t\t\t\t\t\t\t\t</a>\n" +
        "\t\t\t\t\t\t\t</li>\n" +
        "\t\t\t\t\t\t\t<li>\n" +
        "\t\t\t\t\t\t\t\t<a href=\"javascript:adminAlterEmail()\">\n" +
        "\t\t\t\t\t\t\t\t\t<i class=\"iconfont icon-circle-hollow\"></i>\n" +
        "\t\t\t\t\t\t\t\t\t<small>修改邮箱</small>\n" +
        "\t\t\t\t\t\t\t\t</a>\n" +
        "\t\t\t\t\t\t\t</li>\n" +
        "\t\t\t\t\t\t\t<li>\n" +
        "\t\t\t\t\t\t\t\t<a href=\"javascript:adminAlterTel()\">\n" +
        "\t\t\t\t\t\t\t\t\t<i class=\"iconfont icon-circle-hollow\"></i>\n" +
        "\t\t\t\t\t\t\t\t\t<small>修改电话</small>\n" +
        "\t\t\t\t\t\t\t\t</a>\n" +
        "\t\t\t\t\t\t\t</li>\n" +
        "\t\t\t\t\t\t</ul>\n" +
        "\t\t\t\t\t</li>\n" +
        "\t\t\t\t</ul>\n" +
        "\t\t\t</section>\n" +
        "\t\t</aside>";
    footer.innerHTML = content;
}