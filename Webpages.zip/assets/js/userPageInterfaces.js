returnHome=function (){
    const userName = document.getElementById("sideBarUserName").innerText;
    window.location.href="../../../pages/User/home/userHome.html?value=" + userName;
}
allBooksClicked=function(){
    const userName = document.getElementById("sideBarUserName").innerText;
    window.location.href="../../../pages/User/data/allBook.html?value=" + userName;
}
lentBookClicked=function(){
    const userName = document.getElementById("sideBarUserName").innerText;
    window.location.href="../../../pages/User/data/lentBook.html?value=" + userName;
}
searchBook=function(){
    const userName = document.getElementById("sideBarUserName").innerText;
    window.location.href="../../../pages/User/data/searchBook.html?value=" + userName;
}
searchPayment=function(){
    const userName = document.getElementById("sideBarUserName").innerText;
    window.location.href="../../../pages/User/data/searchPayment.html?value=" + userName;
}
userAlterPassword=function (){
    const userName = document.getElementById("sideBarUserName").innerText;
    window.location.href="../../../pages/User/account/userAlterPassword.html?value=" + userName;
}
userAlterEmail=function (){
    const userName = document.getElementById("sideBarUserName").innerText;
    window.location.href="../../../pages/User/account/userAlterEmail.html?value=" + userName;
}
userAlterTel=function (){
    const userName = document.getElementById("sideBarUserName").innerText;
    window.location.href="../../../pages/User/account/userAlterTel.html?value=" + userName;
}
allBreachClicked=function (){
    const userName = document.getElementById("sideBarUserName").innerText;
    window.location.href="../../../pages/User/data/allBreach.html?value=" + userName;
}
gotoUserLogin=function (){
    window.location.href="../../../pages/User/home/userLogin.html";
}
gotoUserRegister=function (){
    window.location.href="../../../pages/User/home/userRegister.html";
}