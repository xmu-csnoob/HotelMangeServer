function fillFooterDOM() {
    var footer = document.getElementById("footer");
    //console.log("fillFooterDOM");
    var content = "<aside class=\"main-sidebar\">\n" +
        "        <div class=\"user-panel\">\n" +
        "            <div class=\"image pull-left\">\n" +
        "                <img src=\"../../../assets/avatars/avatars.png\" alt=\"\">\n" +
        "            </div>\n" +
        "            <div class=\"info pull-right\">\n" +
        "                <p id=\"sideBarUserName\" class=\"title\">Alpha</p>\n" +
        "                <strong>用户</strong>\n" +
        "            </div>\n" +
        "        </div>\n" +
        "        <section class=\"sidebar\">\n" +
        "            <ul class=\"sidebar-menu\" data-widget=\"tree\">\n" +
        "                <li class=\"active\">\n" +
        "                    <a href=\"javascript:returnHome()\" title=\"我的主页\">\n" +
        "                        <i class=\"iconfont icon-dashborad\"></i>\n" +
        "                        <small>我的主页</small>\n" +
        "                    </a>\n" +
        "                </li>\n" +
        "                <li class=\"treeview\">\n" +
        "                    <a href=\"#\" title=\"图书借阅\">\n" +
        "                        <i class=\"iconfont icon-form\"></i>\n" +
        "                        <small>图书借阅</small>\n" +
        "                        <span class=\" pull-right\">\n" +
        "\t\t\t\t\t\t\t\t<i class=\"iconfont icon-menu-left-small\"></i>\n" +
        "\t\t\t\t\t\t\t</span>\n" +
        "                    </a>\n" +
        "                    <ul class=\"treeview-menu\">\n" +
        "                        <li>\n" +
        "                            <a href=\"javascript:allBooksClicked()\">\n" +
        "                                <i class=\"iconfont icon-circle-hollow\"></i>\n" +
        "                                <small>所有图书</small>\n" +
        "                            </a>\n" +
        "                        </li>\n" +
        "                        <li>\n" +
        "                            <a href=\"javascript:lentBookClicked()\">\n" +
        "                                <i class=\"iconfont icon-circle-hollow\"></i>\n" +
        "                                <small>已借图书</small>\n" +
        "                            </a>\n" +
        "                        </li>\n" +
        "                        <li>\n" +
        "                            <a href=\"javascript:searchBook()\">\n" +
        "                                <i class=\"iconfont icon-circle-hollow\"></i>\n" +
        "                                <small>查找图书</small>\n" +
        "                            </a>\n" +
        "                        </li>\n" +
        "                    </ul>\n" +
        "                </li>\n" +
        "                <li class=\"treeview\">\n" +
        "                    <a href=\"#\">\n" +
        "                        <i class=\"iconfont icon-folder\"></i>\n" +
        "                        <small>账号管理</small>\n" +
        "                        <span class=\" pull-right\">\n" +
        "\t\t\t\t\t\t\t\t<i class=\"iconfont icon-menu-left-small\"></i>\n" +
        "\t\t\t\t\t\t\t</span>\n" +
        "                    </a>\n" +
        "                    <ul class=\"treeview-menu\">\n" +
        "                        <li>\n" +
        "                            <a href=\"javascript:userAlterPassword()\">\n" +
        "                                <i class=\"iconfont icon-circle-hollow\"></i>\n" +
        "                                <small>修改密码</small>\n" +
        "                            </a>\n" +
        "                        </li>\n" +
        "                        <li>\n" +
        "                            <a href=\"javascript:userAlterEmail()\">\n" +
        "                                <i class=\"iconfont icon-circle-hollow\"></i>\n" +
        "                                <small>修改邮箱</small>\n" +
        "                            </a>\n" +
        "                        </li>\n" +
        "                        <li>\n" +
        "                            <a href=\"javascript:userAlterTel()\">\n" +
        "                                <i class=\"iconfont icon-circle-hollow\"></i>\n" +
        "                                <small>修改电话</small>\n" +
        "                            </a>\n" +
        "                        </li>\n" +
        "                    </ul>\n" +
        "                </li>\n" +
        "                <li class=\"treeview\">\n" +
        "                    <a href=\"#\">\n" +
        "                        <i class=\"iconfont icon-folder\"></i>\n" +
        "                        <small>借阅管理</small>\n" +
        "                        <span class=\" pull-right\">\n" +
        "\t\t\t\t\t\t\t\t<i class=\"iconfont icon-menu-left-small\"></i>\n" +
        "\t\t\t\t\t\t\t</span>\n" +
        "                    </a>\n" +
        "                    <ul class=\"treeview-menu\">\n" +
        "                        <li>\n" +
        "                            <a href=\"javascript:allBreachClicked()\">\n" +
        "                                <i class=\"iconfont icon-circle-hollow\"></i>\n" +
        "                                <small>查询违章记录</small>\n" +
        "                            </a>\n" +
        "                        </li>\n" +
        "                        <li>\n" +
        "                            <a href=\"javascript:searchPayment()\">\n" +
        "                                <i class=\"iconfont icon-circle-hollow\"></i>\n" +
        "                                <small>查询缴款记录</small>\n" +
        "                            </a>\n" +
        "                        </li>\n" +
        "                    </ul>\n" +
        "                </li>\n" +
        "            </ul>\n" +
        "        </section>\n" +
        "    </aside>";
    footer.innerHTML = content;
}